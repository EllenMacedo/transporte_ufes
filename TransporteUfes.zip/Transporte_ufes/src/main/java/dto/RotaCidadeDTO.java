package dto;

public class RotaCidadeDTO {
    private int idRotaCidade;
    private int idRota;
    private int idCidade;
    private int ordem;

    // Getters and Setters
    public int getIdRotaCidade() {
        return idRotaCidade;
    }

    public void setIdRotaCidade(int idRotaCidade) {
        this.idRotaCidade = idRotaCidade;
    }

    public int getIdRota() {
        return idRota;
    }

    public void setIdRota(int idRota) {
        this.idRota = idRota;
    }

    public int getIdCidade() {
        return idCidade;
    }

    public void setIdCidade(int idCidade) {
        this.idCidade = idCidade;
    }

    public int getOrdem() {
        return ordem;
    }

    public void setOrdem(int ordem) {
        this.ordem = ordem;
    }
}
