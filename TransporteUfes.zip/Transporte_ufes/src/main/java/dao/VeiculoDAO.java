package dao;

import dto.VeiculoDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VeiculoDAO {
    private static final String URL = "jdbc:mysql://localhost:3308/transporte_ufes?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "aluno";

    public Connection conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void inserirVeiculo(VeiculoDTO veiculo) {
        String sql = "INSERT INTO veiculo (placa, modelo, capacidade, status, idMotorista) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, veiculo.getPlaca());
            stmt.setString(2, veiculo.getModelo());
            stmt.setInt(3, veiculo.getCapacidade());
            stmt.setString(4, veiculo.getStatus());
            stmt.setInt(5, veiculo.getIdMotorista());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<VeiculoDTO> listarVeiculos() {
        List<VeiculoDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM veiculo";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                VeiculoDTO veiculo = new VeiculoDTO(
                    rs.getInt("idVeiculo"),
                    rs.getString("placa"),
                    rs.getString("modelo"),
                    rs.getInt("capacidade"),
                    rs.getString("status"),
                    rs.getInt("idMotorista")
                );
                lista.add(veiculo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}