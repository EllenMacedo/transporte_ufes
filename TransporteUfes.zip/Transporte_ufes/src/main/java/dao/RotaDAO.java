package dao;

import dto.RotaDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RotaDAO {
    private static final String URL = "jdbc:mysql://localhost:3308/transporte_ufes";
    private static final String USER = "root";
    private static final String PASSWORD = "aluno";

    // Método para adicionar uma nova rota
    public boolean adicionarRota(RotaDTO rota) {
        String query = "INSERT INTO rota (idCidadeOrigem, idCidadeDestino, duracaoEstimada, direcao) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, rota.getIdCidadeOrigem());
            stmt.setInt(2, rota.getIdCidadeDestino());
            stmt.setTime(3, Time.valueOf(rota.getDuracaoEstimada()));
            stmt.setString(4, rota.getDirecao());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para obter todas as rotas
    public List<RotaDTO> obterRotas() {
        List<RotaDTO> rotas = new ArrayList<>();
        String query = "SELECT * FROM rota";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                RotaDTO rota = new RotaDTO();
                rota.setIdRota(rs.getInt("idRota"));
                rota.setIdCidadeOrigem(rs.getInt("idCidadeOrigem"));
                rota.setIdCidadeDestino(rs.getInt("idCidadeDestino"));
                rota.setDuracaoEstimada(rs.getTime("duracaoEstimada").toLocalTime());
                rota.setDirecao(rs.getString("direcao"));
                rotas.add(rota);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rotas;
    }

    // Método para excluir uma rota
    public boolean excluirRota(int idRota) {
        String query = "DELETE FROM rota WHERE idRota = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, idRota);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
