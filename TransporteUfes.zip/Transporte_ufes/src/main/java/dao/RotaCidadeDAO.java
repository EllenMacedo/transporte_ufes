package dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import dto.RotaCidadeDTO;

public class RotaCidadeDAO {

    private static final String URL = "jdbc:mysql://localhost:3308/transporte_ufes";
    private static final String USER = "root";
    private static final String PASSWORD = "aluno";

    // Método para adicionar uma nova RotaCidade
    public boolean adicionarRotaCidade(RotaCidadeDTO rotaCidade) {
        String query = "INSERT INTO rota_cidade (idRota, idCidade, ordem) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, rotaCidade.getIdRota());
            stmt.setInt(2, rotaCidade.getIdCidade());
            stmt.setInt(3, rotaCidade.getOrdem());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para listar todas as RotaCidade
    public List<RotaCidadeDTO> listarRotaCidades() {
        List<RotaCidadeDTO> lista = new ArrayList<>();
        String query = "SELECT * FROM rota_cidade";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                RotaCidadeDTO rotaCidade = new RotaCidadeDTO();
                rotaCidade.setIdRotaCidade(rs.getInt("idRotaCidade"));
                rotaCidade.setIdRota(rs.getInt("idRota"));
                rotaCidade.setIdCidade(rs.getInt("idCidade"));
                rotaCidade.setOrdem(rs.getInt("ordem"));
                lista.add(rotaCidade);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Método para buscar RotaCidade por idRota
    public List<RotaCidadeDTO> buscarPorRota(int idRota) {
        List<RotaCidadeDTO> lista = new ArrayList<>();
        String query = "SELECT * FROM rota_cidade WHERE idRota = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, idRota);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                RotaCidadeDTO rotaCidade = new RotaCidadeDTO();
                rotaCidade.setIdRotaCidade(rs.getInt("idRotaCidade"));
                rotaCidade.setIdRota(rs.getInt("idRota"));
                rotaCidade.setIdCidade(rs.getInt("idCidade"));
                rotaCidade.setOrdem(rs.getInt("ordem"));
                lista.add(rotaCidade);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
