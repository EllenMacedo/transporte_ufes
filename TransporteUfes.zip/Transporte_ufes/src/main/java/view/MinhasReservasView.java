package view;

import dto.LoginDTO;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class MinhasReservasView extends JFrame {

    private LoginDTO usuario;
    private JTable tabelaReservas;
    private DefaultTableModel modeloTabelaReservas;

    public MinhasReservasView(LoginDTO usuario) {
        this.usuario = usuario;

        setTitle("Minhas Reservas");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Exibe nome do usuário
        JLabel labelUsuario = new JLabel("Minhas Reservas - " + usuario.getNome(), SwingConstants.CENTER);
        add(labelUsuario, BorderLayout.NORTH);

        // Cria a tabela de reservas
        modeloTabelaReservas = new DefaultTableModel();
        modeloTabelaReservas.addColumn("ID Viagem");
        modeloTabelaReservas.addColumn("Data");
        modeloTabelaReservas.addColumn("Hora");
        modeloTabelaReservas.addColumn("Status");

        tabelaReservas = new JTable(modeloTabelaReservas);
        JScrollPane scrollPane = new JScrollPane(tabelaReservas);
        add(scrollPane, BorderLayout.CENTER);

        // Botão de Cancelar Reserva
        JButton botaoCancelarReserva = new JButton("Cancelar Reserva");
        botaoCancelarReserva.addActionListener(e -> cancelarReserva());
        add(botaoCancelarReserva, BorderLayout.SOUTH);

        carregarMinhasReservas();
    }

    private void carregarMinhasReservas() {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/transporte_ufes", "root", "root")) {
            String sql = "SELECT r.idReserva, v.idViagem, v.datas, v.hora, r.status " +
                         "FROM reserva r " +
                         "JOIN viagem v ON r.idViagem = v.idViagem " +
                         "WHERE r.idUsuario = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int idReserva = rs.getInt("idReserva");
                int idViagem = rs.getInt("idViagem");
                String data = rs.getString("datas");
                String hora = rs.getString("hora");
                String status = rs.getString("status");

                modeloTabelaReservas.addRow(new Object[]{idViagem, data, hora, status});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar reservas: " + e.getMessage());
        }
    }




    private void cancelarReserva() {
    int linhaSelecionada = tabelaReservas.getSelectedRow();
    if (linhaSelecionada != -1) {
        int idReserva = (int) modeloTabelaReservas.getValueAt(linhaSelecionada, 0); // Obtém o id da reserva
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/transporte_ufes", "root", "root")) {
            // Atualiza o status da reserva para 'cancelada'
            String sql = "UPDATE reserva SET status = 'cancelada' WHERE idReserva = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, idReserva);
            stmt.executeUpdate();  // Executa a atualização

            // Remove a linha da tabela local
            modeloTabelaReservas.removeRow(linhaSelecionada);

            JOptionPane.showMessageDialog(this, "Reserva cancelada com sucesso!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao cancelar a reserva: " + e.getMessage());
        }
    } else {
        JOptionPane.showMessageDialog(this, "Selecione uma reserva para cancelar.");
    }
}




    public static void main(String[] args) {
        LoginDTO usuario = new LoginDTO();
        usuario.setNome("Aluno Teste");
        usuario.setIdUsuario(1);  // ID fictício para testes
        new MinhasReservasView(usuario).setVisible(true);
    }
}
