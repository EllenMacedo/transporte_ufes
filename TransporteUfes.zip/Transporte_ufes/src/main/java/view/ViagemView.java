package view;

import dao.ViagemDAO;
import dto.ViagemDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ViagemView extends JFrame {
    private JTextField campoIdVeiculo, campoIdMotorista, campoIdRota, campoData, campoHora, campoVagas, campoStatus;
    private JButton btnAdicionar, btnListar, btnAtualizarStatus;
    private JTextArea areaResultado;
    private ViagemDAO viagemDAO;

    public ViagemView() {
        viagemDAO = new ViagemDAO();

        // Configuração da interface gráfica
        setTitle("Viagem");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new FlowLayout());

        campoIdVeiculo = new JTextField(10);
        campoIdMotorista = new JTextField(10);
        campoIdRota = new JTextField(10);
        campoData = new JTextField(10);
        campoHora = new JTextField(5);
        campoVagas = new JTextField(5);
        campoStatus = new JTextField(10);

        btnAdicionar = new JButton("Adicionar");
        btnListar = new JButton("Listar");
        btnAtualizarStatus = new JButton("Atualizar Status");

        areaResultado = new JTextArea(10, 30);
        areaResultado.setEditable(false);

        add(new JLabel("ID Veículo:"));
        add(campoIdVeiculo);
        add(new JLabel("ID Motorista:"));
        add(campoIdMotorista);
        add(new JLabel("ID Rota:"));
        add(campoIdRota);
        add(new JLabel("Data:"));
        add(campoData);
        add(new JLabel("Hora:"));
        add(campoHora);
        add(new JLabel("Vagas Disponíveis:"));
        add(campoVagas);
        add(new JLabel("Status:"));
        add(campoStatus);
        add(btnAdicionar);
        add(btnListar);
        add(btnAtualizarStatus);
        add(new JScrollPane(areaResultado));

        // Ação para adicionar
        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int idVeiculo = Integer.parseInt(campoIdVeiculo.getText());
                int idMotorista = Integer.parseInt(campoIdMotorista.getText());
                int idRota = Integer.parseInt(campoIdRota.getText());
                String data = campoData.getText();
                String hora = campoHora.getText();
                int vagas = Integer.parseInt(campoVagas.getText());
                String status = campoStatus.getText();

                ViagemDTO viagem = new ViagemDTO();
                viagem.setIdVeiculo(idVeiculo);
                viagem.setIdMotorista(idMotorista);
                viagem.setIdRota(idRota);
                viagem.setData(data);
                viagem.setHora(hora);
                viagem.setVagasDisponiveis(vagas);
                viagem.setStatus(status);

                if (viagemDAO.adicionarViagem(viagem)) {
                    JOptionPane.showMessageDialog(ViagemView.this, "Viagem adicionada com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(ViagemView.this, "Erro ao adicionar viagem.");
                }
            }
        });

        // Ação para listar
        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<ViagemDTO> lista = viagemDAO.listarViagens();
                areaResultado.setText("");
                for (ViagemDTO viagem : lista) {
                    areaResultado.append("ID Viagem: " + viagem.getIdViagem() +
                            ", ID Veículo: " + viagem.getIdVeiculo() +
                            ", ID Motorista: " + viagem.getIdMotorista() +
                            ", ID Rota: " + viagem.getIdRota() +
                            ", Data: " + viagem.getData() +
                            ", Hora: " + viagem.getHora() +
                            ", Vagas: " + viagem.getVagasDisponiveis() +
                            ", Status: " + viagem.getStatus() + "\n");
                }
            }
        });

        // Ação para atualizar status
        btnAtualizarStatus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int idViagem = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID da viagem"));
                String novoStatus = JOptionPane.showInputDialog("Digite o novo status");
                if (viagemDAO.atualizarStatus(idViagem, novoStatus)) {
                    JOptionPane.showMessageDialog(ViagemView.this, "Status atualizado com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(ViagemView.this, "Erro ao atualizar status.");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ViagemView().setVisible(true);
            }
        });
    }
}
