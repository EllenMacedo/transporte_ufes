package view;

import dto.LoginDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class AdminView extends JFrame {

    private LoginDTO usuario;
    private JTable tabelaViagens;
    private DefaultTableModel modeloTabelaViagens;

    public AdminView(LoginDTO usuario) {
        this.usuario = usuario;
        setTitle("Tela de Administração");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  // Não fecha o programa ao fechar a janela
        setLayout(new BorderLayout());

        // Exibe nome do usuário
        JLabel labelUsuario = new JLabel("Bem-vindo, " + usuario.getNome(), SwingConstants.CENTER);
        add(labelUsuario, BorderLayout.NORTH);

        // Painel de botões para funcionalidades
        JPanel painelOpcoes = new JPanel();
        painelOpcoes.setLayout(new GridLayout(9, 1)); // Ajustando para 9 botões no total

        // Botão para cadastrar Viagem
        JButton botaoCadastrarViagem = new JButton("Cadastrar Viagem");
        botaoCadastrarViagem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirTelaCadastroViagem();
            }
        });
        painelOpcoes.add(botaoCadastrarViagem);

        // Botão para gerenciar Reservas
        JButton botaoGerenciarReservas = new JButton("Reservar Viagem");
        botaoGerenciarReservas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirTelaGerenciarReservas();
            }
        });
        painelOpcoes.add(botaoGerenciarReservas);

        // Botões de outras funcionalidades (já implementados)
        JButton botaoCadastrarRota = new JButton("Cadastrar Rota");
        botaoCadastrarRota.addActionListener(e -> abrirTelaCadastroRota());
        painelOpcoes.add(botaoCadastrarRota);

        JButton botaoCadastrarVeiculo = new JButton("Cadastrar Veículo");
        botaoCadastrarVeiculo.addActionListener(e -> abrirTelaCadastroVeiculo());
        painelOpcoes.add(botaoCadastrarVeiculo);

        JButton botaoCadastrarUsuario = new JButton("Cadastrar Usuário");
        botaoCadastrarUsuario.addActionListener(e -> abrirTelaCadastroUsuario());
        painelOpcoes.add(botaoCadastrarUsuario);

        JButton botaoCadastrarCidade = new JButton("Cadastrar Cidade");
        botaoCadastrarCidade.addActionListener(e -> {
            try {
                abrirTelaCadastroCidade();
            } catch (SQLException ex) {
                Logger.getLogger(AdminView.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        painelOpcoes.add(botaoCadastrarCidade);

        JButton botaoCadastrarRotaCidade = new JButton("Cadastrar Rota-Cidade");
        botaoCadastrarRotaCidade.addActionListener(e -> abrirTelaCadastroRotaCidade());
        painelOpcoes.add(botaoCadastrarRotaCidade);

        // Adiciona painel de opções na janela
        add(painelOpcoes, BorderLayout.WEST);

        // Adiciona a tabela de viagens
        modeloTabelaViagens = new DefaultTableModel();
        modeloTabelaViagens.addColumn("ID Viagem");
        modeloTabelaViagens.addColumn("Data");
        modeloTabelaViagens.addColumn("Hora");
        modeloTabelaViagens.addColumn("Destino");
        modeloTabelaViagens.addColumn("Vagas Disponíveis");

        tabelaViagens = new JTable(modeloTabelaViagens);
        tabelaViagens.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(tabelaViagens);
        add(scrollPane, BorderLayout.CENTER);

        carregarViagens(); // Carregar as viagens da base de dados
    }

    private void carregarViagens() {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/transporte_ufes", "root", "root")) {
            String sql = "SELECT v.idViagem, v.datas, v.hora, c1.nome AS cidadeOrigem, c2.nome AS cidadeDestino, v.vagasDisponiveis " +
                         "FROM viagem v " +
                         "JOIN rota r ON v.idRota = r.idRota " +
                         "JOIN cidade c1 ON r.idCidadeOrigem = c1.idCidade " +
                         "JOIN cidade c2 ON r.idCidadeDestino = c2.idCidade";
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int idViagem = rs.getInt("idViagem");
                String data = rs.getString("datas");
                String hora = rs.getString("hora");
                String destino = rs.getString("cidadeDestino");
                int vagasDisponiveis = rs.getInt("vagasDisponiveis");

                modeloTabelaViagens.addRow(new Object[]{idViagem, data, hora, destino, vagasDisponiveis});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar viagens: " + e.getMessage());
        }
    }

    private void abrirTelaCadastroViagem() {
        ViagemView viagemView = new ViagemView();
        viagemView.setVisible(true);
    }

    private void abrirTelaGerenciarReservas() {
        int linhaSelecionada = tabelaViagens.getSelectedRow();
        if (linhaSelecionada != -1) {
            int idViagem = (int) modeloTabelaViagens.getValueAt(linhaSelecionada, 0);
            ReservaView reservaView = new ReservaView(usuario, idViagem);  // Passando idViagem
            reservaView.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma viagem para gerenciar a reserva.");
        }
    }

    private void abrirTelaCadastroRota() {
        RotaView rotaView = new RotaView();
        rotaView.setVisible(true);
    }

    private void abrirTelaCadastroVeiculo() {
        VeiculoView veiculoView = new VeiculoView();
        veiculoView.setVisible(true);
    }

    private void abrirTelaCadastroUsuario() {
        UsuarioView usuarioView = new UsuarioView();
        usuarioView.setVisible(true);
    }

    private void abrirTelaCadastroCidade() throws SQLException {
        CidadeView cidadeView = new CidadeView();
        cidadeView.setVisible(true);
    }

    private void abrirTelaCadastroRotaCidade() {
        RotaCidadeView rotaCidadeView = new RotaCidadeView();
        rotaCidadeView.setVisible(true);
    }

    public static void main(String[] args) {
        LoginDTO usuario = new LoginDTO();
        usuario.setNome("Admin Teste");
        new AdminView(usuario).setVisible(true);
    }
}
