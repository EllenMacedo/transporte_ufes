package view;

import dto.LoginDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Stack;
import javax.swing.table.DefaultTableModel;

public class AlunoView extends JFrame {

    private LoginDTO usuario;
    private JTable tabelaViagens;
    private DefaultTableModel modeloTabelaViagens;
    private Stack<Integer> historicoViagensSelecionadas;

    public AlunoView(LoginDTO usuario) {
        this.usuario = usuario;
        this.historicoViagensSelecionadas = new Stack<>(); // Pilha para armazenar histórico de seleções

        setTitle("Tela do Aluno");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  // Não fecha o programa ao fechar a janela
        setLayout(new BorderLayout());

        // Exibe nome do usuário
        JLabel labelUsuario = new JLabel("Bem-vindo, " + usuario.getNome(), SwingConstants.CENTER);
        add(labelUsuario, BorderLayout.NORTH);

        // Painel de botões para funcionalidades
        JPanel painelOpcoes = new JPanel();
        painelOpcoes.setLayout(new GridLayout(4, 1)); // Ajustando para 4 botões no total

        // Botão para visualizar Viagens
        JButton botaoVerViagens = new JButton("Reservar Viagem Selecionada");
        botaoVerViagens.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirTelaVerViagens();
            }
        });
        painelOpcoes.add(botaoVerViagens);

        // Botão para visualizar Reservas
        JButton botaoMinhasReservas = new JButton("Minhas Reservas");
        botaoMinhasReservas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirTelaMinhasReservas();
            }
        });
        painelOpcoes.add(botaoMinhasReservas);

        // Botão Undo
        JButton botaoUndo = new JButton("Desfazer Ultima Ação");
        botaoUndo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                desfazerUltimaAcao();
            }
        });
        painelOpcoes.add(botaoUndo);

        // Adiciona painel de opções na janela
        add(painelOpcoes, BorderLayout.WEST);

        // Adiciona a tabela de viagens
        modeloTabelaViagens = new DefaultTableModel();
        modeloTabelaViagens.addColumn("ID Viagem");
        modeloTabelaViagens.addColumn("Data");
        modeloTabelaViagens.addColumn("Hora");
        modeloTabelaViagens.addColumn("Destino");
        modeloTabelaViagens.addColumn("Vagas Disponíveis");

        tabelaViagens = new JTable(modeloTabelaViagens);
        tabelaViagens.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(tabelaViagens);
        add(scrollPane, BorderLayout.CENTER);

        carregarViagens(); // Carregar as viagens da base de dados
    }

    private void carregarViagens() {
    try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/transporte_ufes", "root", "root")) {
        String sql = "SELECT v.idViagem, v.datas, v.hora, c1.nome AS cidadeOrigem, c2.nome AS cidadeDestino, v.vagasDisponiveis " +
                     "FROM viagem v " +
                     "JOIN rota r ON v.idRota = r.idRota " +
                     "JOIN cidade c1 ON r.idCidadeOrigem = c1.idCidade " +
                     "JOIN cidade c2 ON r.idCidadeDestino = c2.idCidade";
        PreparedStatement stmt = connection.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        // Limpar a tabela antes de recarregar
        modeloTabelaViagens.setRowCount(0);

        while (rs.next()) {
            int idViagem = rs.getInt("idViagem");
            String data = rs.getString("datas");
            String hora = rs.getString("hora");
            String destino = rs.getString("cidadeDestino");
            int vagasDisponiveis = rs.getInt("vagasDisponiveis");

            modeloTabelaViagens.addRow(new Object[]{idViagem, data, hora, destino, vagasDisponiveis});
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Erro ao carregar viagens: " + e.getMessage());
    }
}


    private void abrirTelaVerViagens() {
        int linhaSelecionada = tabelaViagens.getSelectedRow();
        if (linhaSelecionada != -1) {
            int idViagem = (int) modeloTabelaViagens.getValueAt(linhaSelecionada, 0);
            historicoViagensSelecionadas.push(idViagem);  // Salva a seleção na pilha
            ReservaView reservaView = new ReservaView(usuario, idViagem);  // Passando idViagem
            reservaView.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma viagem para realizar a reserva.");
        }
    }

    private void abrirTelaMinhasReservas() {
    // Abre a tela MinhasReservasView
    MinhasReservasView minhasReservasView = new MinhasReservasView(usuario);
    minhasReservasView.setVisible(true);
}

    private void desfazerUltimaAcao() {
        if (!historicoViagensSelecionadas.isEmpty()) {
            int ultimaSelecao = historicoViagensSelecionadas.pop();  // Desfaz a última seleção
            JOptionPane.showMessageDialog(this, "Última viagem selecionada foi: " + ultimaSelecao);
        } else {
            JOptionPane.showMessageDialog(this, "Não há ações para desfazer.");
        }
    }

    public static void main(String[] args) {
        LoginDTO usuario = new LoginDTO();
        usuario.setNome("Aluno Teste");
        new AlunoView(usuario).setVisible(true);
    }
}
