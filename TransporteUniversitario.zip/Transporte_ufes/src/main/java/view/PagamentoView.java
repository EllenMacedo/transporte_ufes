package view;

import dto.LoginDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class PagamentoView extends JFrame {

    private LoginDTO usuario;
    private int idViagem;

    public PagamentoView(LoginDTO usuario, int idViagem) {
        this.usuario = usuario;
        this.idViagem = idViagem;

        setTitle("Tela de Pagamento");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Exibe nome do usuário
        JLabel labelUsuario = new JLabel("Bem-vindo, " + usuario.getNome(), SwingConstants.CENTER);
        add(labelUsuario, BorderLayout.NORTH);

        // Exibe opções de pagamento
        JPanel painelPagamento = new JPanel();
        painelPagamento.setLayout(new GridLayout(3, 1));

        // Método de pagamento
        JComboBox<String> comboBoxPagamento = new JComboBox<>(new String[]{"Cartão de Crédito", "Boleto", "Pix"});
        painelPagamento.add(comboBoxPagamento);

        // Valor do pagamento
        JLabel labelValor = new JLabel("Valor: R$10,00");  // Exemplo de valor fixo
        painelPagamento.add(labelValor);

        // Botão de pagamento
        JButton botaoPagar = new JButton("Realizar Pagamento");
        botaoPagar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarPagamento(comboBoxPagamento.getSelectedItem().toString());
            }
        });

        painelPagamento.add(botaoPagar);
        add(painelPagamento, BorderLayout.CENTER);
    }

    private void realizarPagamento(String metodo) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/transporte_ufes", "root", "root")) {
            String sql = "INSERT INTO pagamento (idUsuario, valor, dataPagamento, metodo, status) VALUES (?, ?, CURDATE(), ?, 'pendente')";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, usuario.getIdUsuario());
            stmt.setDouble(2, 10.00);  // Valor fixo de exemplo
            stmt.setString(3, metodo);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Pagamento realizado com sucesso!");
            dispose();  // Fecha a tela de pagamento
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao realizar pagamento: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        LoginDTO usuario = new LoginDTO();
        usuario.setNome("Aluno Teste");
        new PagamentoView(usuario, 1).setVisible(true);
    }
}
