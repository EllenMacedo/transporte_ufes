package view;

import dao.UsuarioDAO;
import dto.UsuarioDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class UsuarioView extends JFrame {
    private JTextField txtNome, txtEmail, txtSenha, txtTipo, txtMatricula, txtTelefone, txtId;
    private JButton btnSalvar, btnListar, btnExcluir;
    private JTextArea txtAreaUsuarios;
    
    public UsuarioView() {
        setTitle("Cadastro de Usuário");
        setSize(400, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new FlowLayout());
        
        txtNome = new JTextField(20);
        txtEmail = new JTextField(20);
        txtSenha = new JTextField(20);
        txtTipo = new JTextField(10);
        txtMatricula = new JTextField(15);
        txtTelefone = new JTextField(15);
        txtId = new JTextField(5);
        btnSalvar = new JButton("Salvar");
        btnListar = new JButton("Listar Usuários");
        btnExcluir = new JButton("Excluir Usuário");
        txtAreaUsuarios = new JTextArea(10, 30);
        txtAreaUsuarios.setEditable(false);
        
        add(new JLabel("Nome:")); add(txtNome);
        add(new JLabel("Email:")); add(txtEmail);
        add(new JLabel("Senha:")); add(txtSenha);
        add(new JLabel("Tipo:")); add(txtTipo);
        add(new JLabel("Matrícula:")); add(txtMatricula);
        add(new JLabel("Telefone:")); add(txtTelefone);
        add(new JLabel("ID para excluir:")); add(txtId);
        add(btnSalvar); add(btnListar); add(btnExcluir);
        add(new JScrollPane(txtAreaUsuarios));
        
        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salvarUsuario();
            }
        });
        
        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarUsuarios();
            }
        });
        
        btnExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirUsuario();
            }
        });
        
        setVisible(true);
    }
    
    private void salvarUsuario() {
        UsuarioDTO usuario = new UsuarioDTO();
        usuario.setNome(txtNome.getText());
        usuario.setEmail(txtEmail.getText());
        usuario.setSenha(txtSenha.getText());
        usuario.setTipo(txtTipo.getText());
        usuario.setMatricula(txtMatricula.getText());
        usuario.setTelefone(txtTelefone.getText());
        
        UsuarioDAO dao = new UsuarioDAO();
        dao.inserirUsuario(usuario);
        JOptionPane.showMessageDialog(this, "Usuário cadastrado com sucesso!");
        limparCampos();
    }
    
    private void listarUsuarios() {
        UsuarioDAO dao = new UsuarioDAO();
        List<UsuarioDTO> usuarios = dao.listarUsuarios();
        txtAreaUsuarios.setText("");
        for (UsuarioDTO usuario : usuarios) {
            txtAreaUsuarios.append(usuario.getIdUsuario() + " - " + usuario.getNome() + " - " + usuario.getEmail() + "\n");
        }
    }
    
    private void excluirUsuario() {
        int id = Integer.parseInt(txtId.getText());
        UsuarioDAO dao = new UsuarioDAO();
        dao.excluirUsuario(id);
        JOptionPane.showMessageDialog(this, "Usuário excluído com sucesso!");
        listarUsuarios();
        limparCampos();
    }
    
    private void limparCampos() {
        txtNome.setText("");
        txtEmail.setText("");
        txtSenha.setText("");
        txtTipo.setText("");
        txtMatricula.setText("");
        txtTelefone.setText("");
        txtId.setText("");
    }
    
    public static void main(String[] args) {
        new UsuarioView();
    }
}
