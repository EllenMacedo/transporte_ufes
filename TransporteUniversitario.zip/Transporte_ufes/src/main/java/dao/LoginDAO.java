package dao;

import dto.LoginDTO;
import java.sql.*;

public class LoginDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/transporte_ufes";
    private static final String USER = "root";
    private static final String PASSWORD = "aluno";

    public LoginDTO autenticarUsuario(String email, String senha) {
        String query = "SELECT * FROM usuario WHERE email = ? AND senha = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, email);
            stmt.setString(2, senha);  // Considere usar uma hash de senha em um sistema real

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                LoginDTO usuario = new LoginDTO();
                usuario.setIdUsuario(rs.getInt("idUsuario"));
                usuario.setNome(rs.getString("nome"));
                usuario.setEmail(rs.getString("email"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setTipo(rs.getString("tipo"));
                usuario.setMatricula(rs.getString("matricula"));
                usuario.setTelefone(rs.getString("telefone"));
                return usuario;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
