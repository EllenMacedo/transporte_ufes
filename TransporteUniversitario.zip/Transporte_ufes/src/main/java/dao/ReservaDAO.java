package dao;
import dto.ReservaDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservaDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/transporte_ufes";
    private static final String USER = "root";
    private static final String PASSWORD = "aluno";

    // Método para adicionar uma nova reserva
    public boolean adicionarReserva(ReservaDTO reserva) {
        String query = "INSERT INTO reserva (idUsuario, idViagem, status) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, reserva.getIdUsuario());
            stmt.setInt(2, reserva.getIdViagem());
            stmt.setString(3, reserva.getStatus());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para listar todas as reservas
    public List<ReservaDTO> listarReservas() {
        List<ReservaDTO> lista = new ArrayList<>();
        String query = "SELECT * FROM reserva";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                ReservaDTO reserva = new ReservaDTO();
                reserva.setIdReserva(rs.getInt("idReserva"));
                reserva.setIdUsuario(rs.getInt("idUsuario"));
                reserva.setIdViagem(rs.getInt("idViagem"));
                reserva.setStatus(rs.getString("status"));
                lista.add(reserva);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Método para atualizar o status de uma reserva
    public boolean atualizarStatus(int idReserva, String novoStatus) {
        String query = "UPDATE reserva SET status = ? WHERE idReserva = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, novoStatus);
            stmt.setInt(2, idReserva);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
