package dao;

import dto.CidadeDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CidadeDAO {
    private Connection connection;

    public CidadeDAO() {
        try {
            // Conectar ao banco de dados
            this.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/transporte_ufes", "root", "aluno");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean adicionarCidade(CidadeDTO cidade) {
        String sql = "INSERT INTO cidade (nome, uf) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, cidade.getNome());
            stmt.setString(2, cidade.getUf());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<CidadeDTO> listarCidades() {
        List<CidadeDTO> cidades = new ArrayList<>();
        String sql = "SELECT * FROM cidade";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                CidadeDTO cidade = new CidadeDTO();
                cidade.setIdCidade(rs.getInt("idCidade"));
                cidade.setNome(rs.getString("nome"));
                cidade.setUf(rs.getString("uf"));
                cidades.add(cidade);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cidades;
    }

    public boolean atualizarCidade(CidadeDTO cidade) {
        String sql = "UPDATE cidade SET nome = ?, uf = ? WHERE idCidade = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, cidade.getNome());
            stmt.setString(2, cidade.getUf());
            stmt.setInt(3, cidade.getIdCidade());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluirCidade(int idCidade) {
        String sql = "DELETE FROM cidade WHERE idCidade = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idCidade);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
