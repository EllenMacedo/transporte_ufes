package dao;

import dto.PagamentoDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PagamentoDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/transporte_ufes";
    private static final String USER = "root";
    private static final String PASSWORD = "aluno";

    // Método para adicionar um novo pagamento
    public boolean adicionarPagamento(PagamentoDTO pagamento) {
        String query = "INSERT INTO pagamento (idUsuario, valor, dataPagamento, metodo, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, pagamento.getIdUsuario());
            stmt.setDouble(2, pagamento.getValor());
            stmt.setString(3, pagamento.getDataPagamento());
            stmt.setString(4, pagamento.getMetodo());
            stmt.setString(5, pagamento.getStatus());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para listar todos os pagamentos
    public List<PagamentoDTO> listarPagamentos() {
        List<PagamentoDTO> lista = new ArrayList<>();
        String query = "SELECT * FROM pagamento";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                PagamentoDTO pagamento = new PagamentoDTO();
                pagamento.setIdPagamento(rs.getInt("idPagamento"));
                pagamento.setIdUsuario(rs.getInt("idUsuario"));
                pagamento.setValor(rs.getDouble("valor"));
                pagamento.setDataPagamento(rs.getString("dataPagamento"));
                pagamento.setMetodo(rs.getString("metodo"));
                pagamento.setStatus(rs.getString("status"));
                lista.add(pagamento);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Método para atualizar o status de um pagamento
    public boolean atualizarStatus(int idPagamento, String novoStatus) {
        String query = "UPDATE pagamento SET status = ? WHERE idPagamento = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, novoStatus);
            stmt.setInt(2, idPagamento);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
