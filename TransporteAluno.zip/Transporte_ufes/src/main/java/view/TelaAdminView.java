package view;

import dto.LoginDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaAdminView extends JFrame {

    private LoginDTO usuario;

    public TelaAdminView(LoginDTO usuario) {
        this.usuario = usuario;
        setTitle("Funcionalidades de Administrador");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centraliza a janela
        setLayout(new GridLayout(5, 1));

        JButton cadastroUsuario = new JButton("Cadastro de Usuário");
        JButton cadastroVeiculo = new JButton("Cadastro de Veículo");
        JButton cadastroRota = new JButton("Cadastro de Rota");
        JButton cadastroCidade = new JButton("Cadastro de Cidade");
        JButton cadastroViagem = new JButton("Cadastro de Viagem");

        // Adicionando os botões para as funcionalidades
        cadastroUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Redirecionar para a tela de cadastro de usuário
                new UsuarioView().setVisible(true);
            }
        });

        cadastroVeiculo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Redirecionar para a tela de cadastro de veículo
                new VeiculoView().setVisible(true);
            }
        });

        // Adicionar outros botões conforme as funcionalidades necessárias...

        add(cadastroUsuario);
        add(cadastroVeiculo);
        add(cadastroRota);
        add(cadastroCidade);
        add(cadastroViagem);
    }
}
