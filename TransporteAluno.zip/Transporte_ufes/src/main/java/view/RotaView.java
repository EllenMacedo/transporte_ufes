package view;

import dao.RotaDAO;
import dto.RotaDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.util.List;

public class RotaView extends JFrame {

    private RotaDAO rotaDAO = new RotaDAO();
    private JTextField campoCidadeOrigem;
    private JTextField campoCidadeDestino;
    private JTextField campoDuracao;
    private JTextField campoDirecao;
    private JTextArea areaRotas;

    public RotaView() {
        setTitle("Cadastro de Rota");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2));

        panel.add(new JLabel("Cidade Origem:"));
        campoCidadeOrigem = new JTextField();
        panel.add(campoCidadeOrigem);

        panel.add(new JLabel("Cidade Destino:"));
        campoCidadeDestino = new JTextField();
        panel.add(campoCidadeDestino);

        panel.add(new JLabel("Duração Estimada (HH:mm:ss):"));
        campoDuracao = new JTextField();
        panel.add(campoDuracao);

        panel.add(new JLabel("Direção:"));
        campoDirecao = new JTextField();
        panel.add(campoDirecao);

        JButton botaoAdicionar = new JButton("Adicionar Rota");
        botaoAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarRota();
            }
        });

        add(panel, BorderLayout.NORTH);
        add(botaoAdicionar, BorderLayout.SOUTH);

        areaRotas = new JTextArea();
        areaRotas.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaRotas);
        add(scroll, BorderLayout.CENTER);

        exibirRotas();
    }

    private void adicionarRota() {
        try {
            int cidadeOrigem = Integer.parseInt(campoCidadeOrigem.getText());
            int cidadeDestino = Integer.parseInt(campoCidadeDestino.getText());

            // Verificando se o campo de duração está no formato correto (HH:mm:ss)
            String duracaoTexto = campoDuracao.getText();
            LocalTime duracao = null;
            try {
                duracao = LocalTime.parse(duracaoTexto); // Tenta converter o texto para LocalTime
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Formato de duração inválido. Use HH:mm:ss.");
                return;
            }

            String direcao = campoDirecao.getText();

            RotaDTO rota = new RotaDTO();
            rota.setIdCidadeOrigem(cidadeOrigem);
            rota.setIdCidadeDestino(cidadeDestino);
            rota.setDuracaoEstimada(duracao);
            rota.setDirecao(direcao);

            if (rotaDAO.adicionarRota(rota)) {
                JOptionPane.showMessageDialog(this, "Rota adicionada com sucesso!");
                exibirRotas();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao adicionar rota.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Cidade Origem e Cidade Destino devem ser números.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro nos dados: " + e.getMessage());
        }
    }

    private void exibirRotas() {
        List<RotaDTO> rotas = rotaDAO.obterRotas();
        areaRotas.setText("");
        for (RotaDTO rota : rotas) {
            areaRotas.append(rota.toString() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                RotaView view = new RotaView();
                view.setVisible(true);
            }
        });
    }
}
