package view;

import dao.RotaCidadeDAO;
import dto.RotaCidadeDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class RotaCidadeView extends JFrame {
    private JTextField campoIdRota, campoIdCidade, campoOrdem;
    private JButton btnAdicionar, btnListar;
    private JTextArea areaResultado;
    private RotaCidadeDAO rotaCidadeDAO;

    public RotaCidadeView() {
        rotaCidadeDAO = new RotaCidadeDAO();
        
        // Configuração da interface gráfica
        setTitle("RotaCidade");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new FlowLayout());

        campoIdRota = new JTextField(10);
        campoIdCidade = new JTextField(10);
        campoOrdem = new JTextField(10);

        btnAdicionar = new JButton("Adicionar");
        btnListar = new JButton("Listar");

        areaResultado = new JTextArea(10, 30);
        areaResultado.setEditable(false);

        add(new JLabel("ID Rota:"));
        add(campoIdRota);
        add(new JLabel("ID Cidade:"));
        add(campoIdCidade);
        add(new JLabel("Ordem:"));
        add(campoOrdem);
        add(btnAdicionar);
        add(btnListar);
        add(new JScrollPane(areaResultado));

        // Ação para adicionar
        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int idRota = Integer.parseInt(campoIdRota.getText());
                int idCidade = Integer.parseInt(campoIdCidade.getText());
                int ordem = Integer.parseInt(campoOrdem.getText());

                RotaCidadeDTO rotaCidade = new RotaCidadeDTO();
                rotaCidade.setIdRota(idRota);
                rotaCidade.setIdCidade(idCidade);
                rotaCidade.setOrdem(ordem);

                if (rotaCidadeDAO.adicionarRotaCidade(rotaCidade)) {
                    JOptionPane.showMessageDialog(RotaCidadeView.this, "RotaCidade adicionada com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(RotaCidadeView.this, "Erro ao adicionar RotaCidade.");
                }
            }
        });

        // Ação para listar
        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<RotaCidadeDTO> lista = rotaCidadeDAO.listarRotaCidades();
                areaResultado.setText("");
                for (RotaCidadeDTO rotaCidade : lista) {
                    areaResultado.append("ID RotaCidade: " + rotaCidade.getIdRotaCidade() +
                            ", ID Rota: " + rotaCidade.getIdRota() +
                            ", ID Cidade: " + rotaCidade.getIdCidade() +
                            ", Ordem: " + rotaCidade.getOrdem() + "\n");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RotaCidadeView().setVisible(true);
            }
        });
    }
}
