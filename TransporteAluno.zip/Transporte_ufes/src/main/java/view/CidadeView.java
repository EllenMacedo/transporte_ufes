package view;

import dao.CidadeDAO;
import dto.CidadeDTO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;

public class CidadeView {

    private JFrame frame;
    private JTable table;
    private CidadeDAO cidadeDAO;
    private JTextField campoNome;
    private JTextField campoUf;
    private JPanel panel;

    public CidadeView() throws SQLException {
        cidadeDAO = new CidadeDAO();
        frame = new JFrame("Cadastro de Cidades");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLayout(new BorderLayout());

        // Tabela
        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Painel de Formulários
        panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));

        panel.add(new JLabel("Nome:"));
        campoNome = new JTextField();
        panel.add(campoNome);

        panel.add(new JLabel("UF:"));
        campoUf = new JTextField();
        panel.add(campoUf);

        frame.add(panel, BorderLayout.NORTH);

        // Painel de Botões
        JPanel panelBotoes = new JPanel();
        panelBotoes.setLayout(new FlowLayout(FlowLayout.LEFT));

        // Botão Carregar
        JButton btnCarregar = new JButton("Carregar Cidades");
        btnCarregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    carregarCidades();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(frame, "Erro ao carregar cidades: " + ex.getMessage());
                }
            }
        });

        // Botão Adicionar Cidade
        JButton btnAdicionar = new JButton("Adicionar Cidade");
        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    adicionarCidade();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(frame, "Erro ao adicionar cidade: " + ex.getMessage());
                }
            }
        });

        // Botão Excluir Cidade
        JButton btnExcluir = new JButton("Excluir Cidade");
        btnExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    excluirCidade();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(frame, "Erro ao excluir cidade: " + ex.getMessage());
                }
            }
        });

        panelBotoes.add(btnCarregar);
        panelBotoes.add(btnAdicionar);
        panelBotoes.add(btnExcluir);

        frame.add(panelBotoes, BorderLayout.SOUTH);
    }

    public void exibir() {
        frame.setVisible(true);
    }

    private void adicionarCidade() throws SQLException {
        String nome = campoNome.getText();
        String uf = campoUf.getText();

        if (nome.isEmpty() || uf.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Preencha todos os campos.");
            return;
        }

        CidadeDTO cidade = new CidadeDTO();
        cidade.setNome(nome);
        cidade.setUf(uf);

        if (cidadeDAO.adicionarCidade(cidade)) {
            JOptionPane.showMessageDialog(frame, "Cidade adicionada com sucesso!");
            carregarCidades();
        } else {
            JOptionPane.showMessageDialog(frame, "Erro ao adicionar cidade.");
        }
    }

    private void excluirCidade() throws SQLException {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Selecione uma cidade para excluir.");
            return;
        }

        int idCidade = (int) table.getValueAt(selectedRow, 0); // Obtém o ID da cidade selecionada

        int confirm = JOptionPane.showConfirmDialog(frame, "Tem certeza que deseja excluir a cidade?", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (cidadeDAO.excluirCidade(idCidade)) {
                JOptionPane.showMessageDialog(frame, "Cidade excluída com sucesso!");
                carregarCidades();
            } else {
                JOptionPane.showMessageDialog(frame, "Erro ao excluir cidade.");
            }
        }
    }

    private void carregarCidades() throws SQLException {
        List<CidadeDTO> cidades = cidadeDAO.listarCidades();
        String[] colunas = {"ID", "Nome", "UF"};
        Object[][] dados = new Object[cidades.size()][3];

        for (int i = 0; i < cidades.size(); i++) {
            dados[i][0] = cidades.get(i).getIdCidade();
            dados[i][1] = cidades.get(i).getNome();
            dados[i][2] = cidades.get(i).getUf();
        }

        table.setModel(new javax.swing.table.DefaultTableModel(dados, colunas));
    }

    public static void main(String[] args) throws SQLException {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    CidadeView view = new CidadeView();
                    view.exibir();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "Erro ao inicializar a view: " + e.getMessage());
                }
            }
        });
    }

    public void setVisible(boolean visible) {
        frame.setVisible(visible);
    }

}
