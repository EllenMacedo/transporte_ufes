package view;

import dto.LoginDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ReservaView extends JFrame {

    private LoginDTO usuario;
    private int idViagem;

    public ReservaView(LoginDTO usuario, int idViagem) {
        this.usuario = usuario;
        this.idViagem = idViagem;

        setTitle("Tela de Reserva");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Exibe nome do usuário
        JLabel labelUsuario = new JLabel("Bem-vindo, " + usuario.getNome(), SwingConstants.CENTER);
        add(labelUsuario, BorderLayout.NORTH);

        // Exibe detalhes da viagem
        JLabel labelDetalhes = new JLabel("Detalhes da Viagem", SwingConstants.CENTER);
        add(labelDetalhes, BorderLayout.CENTER);

        // Botão para confirmar reserva
        JButton botaoReservar = new JButton("Confirmar Reserva");
        botaoReservar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                confirmarReserva();
            }
        });
        add(botaoReservar, BorderLayout.SOUTH);
    }

    private void confirmarReserva() {
    try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/transporte_ufes", "root", "root")) {
        // Inserir a reserva no banco com o status "pendente"
        String sql = "INSERT INTO reserva (idUsuario, idViagem, status) VALUES (?, ?, 'pendente')";
        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setInt(1, usuario.getIdUsuario());
        stmt.setInt(2, idViagem);
        stmt.executeUpdate();

        // Agora, alteramos o status para "confirmada"
        String updateSql = "UPDATE reserva SET status = 'confirmada' WHERE idUsuario = ? AND idViagem = ?";
        PreparedStatement updateStmt = connection.prepareStatement(updateSql);
        updateStmt.setInt(1, usuario.getIdUsuario());
        updateStmt.setInt(2, idViagem);
        updateStmt.executeUpdate();

        JOptionPane.showMessageDialog(this, "Reserva confirmada com sucesso!");

        // Redireciona para a tela de pagamento após a reserva
        PagamentoView pagamentoView = new PagamentoView(usuario, idViagem);
        pagamentoView.setVisible(true);
        dispose(); // Fecha a tela de reserva
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Erro ao confirmar reserva: " + e.getMessage());
    }
}



    public static void main(String[] args) {
        LoginDTO usuario = new LoginDTO();
        usuario.setNome("Aluno Teste");
        new ReservaView(usuario, 1).setVisible(true);
    }
}
