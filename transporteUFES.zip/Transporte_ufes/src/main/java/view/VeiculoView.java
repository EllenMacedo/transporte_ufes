package view;

import dao.VeiculoDAO;
import dto.VeiculoDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class VeiculoView {
    private JFrame frame;
    private JTextField placaField, modeloField, capacidadeField, statusField, idMotoristaField;
    private JTextArea outputArea;
    private VeiculoDAO veiculoDAO;

    public VeiculoView() {
        veiculoDAO = new VeiculoDAO();
        frame = new JFrame("Gerenciar Veículos");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setLayout(new GridLayout(7, 2));

        frame.add(new JLabel("Placa:"));
        placaField = new JTextField();
        frame.add(placaField);

        frame.add(new JLabel("Modelo:"));
        modeloField = new JTextField();
        frame.add(modeloField);

        frame.add(new JLabel("Capacidade:"));
        capacidadeField = new JTextField();
        frame.add(capacidadeField);

        frame.add(new JLabel("Status:"));
        statusField = new JTextField("ativo");
        frame.add(statusField);

        frame.add(new JLabel("ID Motorista:"));
        idMotoristaField = new JTextField();
        frame.add(idMotoristaField);

        JButton salvarButton = new JButton("Salvar Veículo");
        salvarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salvarVeiculo();
            }
        });
        frame.add(salvarButton);

        JButton listarButton = new JButton("Listar Veículos");
        listarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarVeiculos();
            }
        });
        frame.add(listarButton);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        frame.add(new JScrollPane(outputArea));

        frame.setVisible(true);
    }

    private void salvarVeiculo() {
        VeiculoDTO veiculo = new VeiculoDTO(
            0,
            placaField.getText(),
            modeloField.getText(),
            Integer.parseInt(capacidadeField.getText()),
            statusField.getText(),
            Integer.parseInt(idMotoristaField.getText())
        );
        veiculoDAO.inserirVeiculo(veiculo);
        JOptionPane.showMessageDialog(frame, "Veículo cadastrado com sucesso!");
    }

    private void listarVeiculos() {
        List<VeiculoDTO> lista = veiculoDAO.listarVeiculos();
        outputArea.setText("");
        for (VeiculoDTO v : lista) {
            outputArea.append("ID: " + v.getIdVeiculo() + " | Placa: " + v.getPlaca() + " | Modelo: " + v.getModelo() + "\n");
        }
    }

    public static void main(String[] args) {
        new VeiculoView();
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
