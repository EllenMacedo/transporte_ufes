package view;

import dao.LoginDAO;
import dto.LoginDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginView extends JFrame {

    private JTextField campoEmail;
    private JPasswordField campoSenha;
    private LoginDAO loginDAO;
    private LoginDTO usuarioAutenticado; // <- Adicionado para armazenar usuário logado

    public LoginView() {
        loginDAO = new LoginDAO();  // Acesso à DAO para validação

        setTitle("Login");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(4, 2));

        JLabel labelEmail = new JLabel("Email:");
        JLabel labelSenha = new JLabel("Senha:");

        campoEmail = new JTextField();
        campoSenha = new JPasswordField();

        JButton botaoLogin = new JButton("Entrar");
        botaoLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                autenticar();
            }
        });

        add(labelEmail);
        add(campoEmail);
        add(labelSenha);
        add(campoSenha);
        add(new JLabel());  // Espaço vazio
        add(botaoLogin);
    }

    private void autenticar() {
        String email = campoEmail.getText();
        String senha = new String(campoSenha.getPassword());

        usuarioAutenticado = loginDAO.autenticarUsuario(email, senha); // Salva o usuário autenticado

        if (usuarioAutenticado != null) {
            JOptionPane.showMessageDialog(this, "Bem-vindo, " + usuarioAutenticado.getNome());

            if (usuarioAutenticado.getTipo().equalsIgnoreCase("Aluno")) {
                new AlunoView(usuarioAutenticado).setVisible(true); // Abre a tela do aluno
            } else if (usuarioAutenticado.getTipo().equalsIgnoreCase("Admin")) {
                new AdminView(usuarioAutenticado).setVisible(true); // Abre a tela do admin (caso exista)
            }

            this.dispose(); // Fecha a tela de login
        } else {
            JOptionPane.showMessageDialog(this, "Email ou senha inválidos.");
        }

    }

    public LoginDTO getUsuarioAutenticado() {
        return usuarioAutenticado;
    }
}
