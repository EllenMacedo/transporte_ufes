package dao;

import dto.ViagemDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ViagemDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/transporte_ufes";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    // Método para adicionar uma nova viagem
    public boolean adicionarViagem(ViagemDTO viagem) {
    String query = "INSERT INTO viagem (idVeiculo, idMotorista, idRota, datas, hora, vagasDisponiveis, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setInt(1, viagem.getIdVeiculo());
        stmt.setInt(2, viagem.getIdMotorista());
        stmt.setInt(3, viagem.getIdRota());

        // Converte a data e a hora para os formatos corretos
        java.sql.Date dataSql = java.sql.Date.valueOf(viagem.getData());
        java.sql.Time horaSql = java.sql.Time.valueOf(viagem.getHora());

        stmt.setDate(4, dataSql);
        stmt.setTime(5, horaSql);
        stmt.setInt(6, viagem.getVagasDisponiveis());
        stmt.setString(7, viagem.getStatus());

        int rowsAffected = stmt.executeUpdate();
        return rowsAffected > 0;

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Erro ao adicionar viagem: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}


    // Método para listar todas as viagens
    public List<ViagemDTO> listarViagens() {
        List<ViagemDTO> lista = new ArrayList<>();
        String query = "SELECT * FROM viagem";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                ViagemDTO viagem = new ViagemDTO();
                viagem.setIdViagem(rs.getInt("idViagem"));
                viagem.setIdVeiculo(rs.getInt("idVeiculo"));
                viagem.setIdMotorista(rs.getInt("idMotorista"));
                viagem.setIdRota(rs.getInt("idRota"));
                viagem.setData(rs.getString("datas"));
                viagem.setHora(rs.getString("hora"));
                viagem.setVagasDisponiveis(rs.getInt("vagasDisponiveis"));
                viagem.setStatus(rs.getString("status"));
                lista.add(viagem);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    
    

    // Método para atualizar o status de uma viagem
    public boolean atualizarStatus(int idViagem, String novoStatus) {
        String query = "UPDATE viagem SET status = ? WHERE idViagem = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, novoStatus);
            stmt.setInt(2, idViagem);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
