package dto;

public class VeiculoDTO {
    private int idVeiculo;
    private String placa;
    private String modelo;
    private int capacidade;
    private String status;
    private int idMotorista;

    public VeiculoDTO() {}

    public VeiculoDTO(int idVeiculo, String placa, String modelo, int capacidade, String status, int idMotorista) {
        this.idVeiculo = idVeiculo;
        this.placa = placa;
        this.modelo = modelo;
        this.capacidade = capacidade;
        this.status = status;
        this.idMotorista = idMotorista;
    }

    public int getIdVeiculo() { return idVeiculo; }
    public void setIdVeiculo(int idVeiculo) { this.idVeiculo = idVeiculo; }

    public String getPlaca() { return placa; }
    public void setPlaca(String placa) { this.placa = placa; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public int getCapacidade() { return capacidade; }
    public void setCapacidade(int capacidade) { this.capacidade = capacidade; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public int getIdMotorista() { return idMotorista; }
    public void setIdMotorista(int idMotorista) { this.idMotorista = idMotorista; }
}