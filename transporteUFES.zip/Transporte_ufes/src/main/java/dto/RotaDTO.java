package dto;

import java.time.LocalTime;

public class RotaDTO {
    private int idRota;
    private int idCidadeOrigem;
    private int idCidadeDestino;
    private LocalTime duracaoEstimada;
    private String direcao;

    // Getters e Setters
    public int getIdRota() {
        return idRota;
    }

    public void setIdRota(int idRota) {
        this.idRota = idRota;
    }

    public int getIdCidadeOrigem() {
        return idCidadeOrigem;
    }

    public void setIdCidadeOrigem(int idCidadeOrigem) {
        this.idCidadeOrigem = idCidadeOrigem;
    }

    public int getIdCidadeDestino() {
        return idCidadeDestino;
    }

    public void setIdCidadeDestino(int idCidadeDestino) {
        this.idCidadeDestino = idCidadeDestino;
    }

    public LocalTime getDuracaoEstimada() {
        return duracaoEstimada;
    }

    public void setDuracaoEstimada(LocalTime duracaoEstimada) {
        this.duracaoEstimada = duracaoEstimada;
    }

    public String getDirecao() {
        return direcao;
    }

    public void setDirecao(String direcao) {
        this.direcao = direcao;
    }

    @Override
    public String toString() {
        return "RotaDTO{" +
               "idRota=" + idRota +
               ", idCidadeOrigem=" + idCidadeOrigem +
               ", idCidadeDestino=" + idCidadeDestino +
               ", duracaoEstimada=" + duracaoEstimada +
               ", direcao='" + direcao + '\'' +
               '}';
    }
}
